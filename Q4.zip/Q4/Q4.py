n=[1,2,3,4,5,6]
s=list(map(lambda x: x**2, n))
print(s)