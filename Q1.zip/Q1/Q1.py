l=[1,2,3,3,4,4,2,5]
list=list(set(l))
print(list)
