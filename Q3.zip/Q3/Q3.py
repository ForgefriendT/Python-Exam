t1,t2,t3=(1,2,3,4),(3,5,2,1),(2,2,3,1)
sumoftuple=tuple(map(sum, zip (t1,t2,t3)))
print(sumoftuple)